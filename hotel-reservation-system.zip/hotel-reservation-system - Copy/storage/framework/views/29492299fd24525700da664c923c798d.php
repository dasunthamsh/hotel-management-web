<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Revenue Report - <?php echo e(date('Y-m-d')); ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .filters { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Revenue Report - <?php echo e(date('Y-m-d')); ?></h1>
    <div class="filters">
        <p><strong>Branch:</strong> <?php echo e(Auth::user()->branch->name); ?></p>
        <p><strong>Date Range:</strong> <?php echo e($filters['date_range']); ?></p>
    </div>
    <?php if($reports->isEmpty()): ?>
        <p>No revenue reports found for the selected criteria.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Total Revenue ($)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($report->date); ?></td>
                        <td><?php echo e(number_format($report->total_revenue ?? 0, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Development\hotel-reservation-system\resources\views/manager/revenue-report-pdf.blade.php ENDPATH**/ ?>