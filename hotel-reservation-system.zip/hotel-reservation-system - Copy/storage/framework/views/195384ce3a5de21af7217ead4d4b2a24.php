<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Occupancy Report - <?php echo e(date('Y-m-d')); ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .filters { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Occupancy Report - <?php echo e(date('Y-m-d')); ?></h1>
    <div class="filters">
        <p><strong>Branch:</strong> <?php echo e(Auth::user()->branch->name); ?></p>
        <p><strong>Date Range:</strong> <?php echo e($filters['date_range']); ?></p>
        <p><strong>Room Type:</strong> <?php echo e($filters['room_type']); ?></p>
        <p><strong>Status:</strong> <?php echo e($filters['status']); ?></p>
    </div>
    <?php if($reservations->isEmpty()): ?>
        <p>No reservations found for the selected criteria.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Guest Name</th>
                    <th>Room Type</th>
                    <th>Check-In Date</th>
                    <th>Check-Out Date</th>
                    <th>Status</th>
                    <th>Total Price ($)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($reservation->user->name); ?></td>
                        <td><?php echo e($reservation->roomType->name); ?></td>
                        <td><?php echo e($reservation->check_in_date->format('Y-m-d')); ?></td>
                        <td><?php echo e($reservation->check_out_date->format('Y-m-d')); ?></td>
                        <td><?php echo e(ucfirst($reservation->status)); ?></td>
                        <td><?php echo e(number_format($reservation->total_amount ?? 0, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Development\hotel-reservation-system\resources\views/manager/occupancy-report-pdf.blade.php ENDPATH**/ ?>