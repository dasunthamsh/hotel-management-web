

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Room Availability Calendar (<?php echo e(Auth::user()->branch->name); ?>)</h2>
    <div id="calendar"></div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.15/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.15/index.global.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            events: [
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    title: '<?php echo e($reservation->roomType->name); ?> (<?php echo e($reservation->status); ?>)',
                    start: '<?php echo e($reservation->check_in_date->format('Y-m-d')); ?>',
                    end: '<?php echo e($reservation->check_out_date->addDay()->format('Y-m-d')); ?>', // Add 1 day for exclusive end date
                    color: '<?php echo e($reservation->status === 'checked_in' ? '#28a745' : ($reservation->status === 'pending' ? '#ffc107' : '#007bff')); ?>'
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            eventClick: function(info) {
                alert('Reservation: ' + info.event.title + '\nStart: ' + info.event.start.toISOString().split('T')[0] + '\nEnd: ' + info.event.end.toISOString().split('T')[0]);
            }
        });
        calendar.render();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\hotel-reservation-system\resources\views/manager/calendar-view.blade.php ENDPATH**/ ?>