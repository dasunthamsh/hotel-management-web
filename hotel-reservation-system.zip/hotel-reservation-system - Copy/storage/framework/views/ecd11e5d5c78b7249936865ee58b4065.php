

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Revenue Report</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Filter Form -->
    <div class="mb-4">
        <form method="GET" action="<?php echo e(route('manager.revenue-report')); ?>">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="date_range" class="form-label">Date Range</label>
                    <input type="text" name="date_range" id="date_range" class="form-control" placeholder="Select date range" value="<?php echo e(request('date_range')); ?>">
                </div>
                <div class="col-md-2 mb-3 align-self-end">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="<?php echo e(route('manager.revenue-report')); ?>" class="btn btn-secondary">Clear</a>
                </div>
            </div>
        </form>
    </div>

    <!-- Download Buttons -->
    <div class="mb-4">
        <a href="<?php echo e(route('manager.download-revenue-report', ['format' => 'pdf', 'date_range' => request('date_range')])); ?>" class="btn btn-primary">Download PDF</a>
        <a href="<?php echo e(route('manager.download-revenue-report', ['format' => 'excel', 'date_range' => request('date_range')])); ?>" class="btn btn-success">Download Excel</a>
    </div>

    <!-- Reports Table -->
    <?php if($reports->isEmpty()): ?>
        <p>No revenue reports found for the selected criteria.</p>
    <?php else: ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Total Revenue ($)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($report->date); ?></td>
                        <td><?php echo e(number_format($report->total_revenue ?? 0, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- DateRangePicker Dependencies -->
<link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>
$(function() {
    $('#date_range').daterangepicker({
        opens: 'left',
        locale: {
            format: 'YYYY-MM-DD'
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\hotel-reservation-system\resources\views/manager/revenue-report.blade.php ENDPATH**/ ?>