

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Manager Dashboard</h2>

    <div class="row mt-4">
        <div class="col-md-4 mb-3">
            <a href="<?php echo e(route('manager.occupancy-report')); ?>" class="btn btn-primary btn-lg w-100">Occupancy Reports</a>
        </div>
        <div class="col-md-4 mb-3">
            <a href="<?php echo e(route('manager.revenue-report')); ?>" class="btn btn-primary btn-lg w-100">Revenue Reports</a>
        </div>
        <div class="col-md-4 mb-3">
            <a href="<?php echo e(route('manager.calendar-view')); ?>" class="btn btn-primary btn-lg w-100">Calendar View</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Development\hotel-reservation-system\resources\views/manager/dashboard.blade.php ENDPATH**/ ?>